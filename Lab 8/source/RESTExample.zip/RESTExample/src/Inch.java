
public class Inch {
	public int convertinch(int var1) {
		int x=64;
		System.out.println("Centimetres into feet" + x );
		return x;
	}


}
