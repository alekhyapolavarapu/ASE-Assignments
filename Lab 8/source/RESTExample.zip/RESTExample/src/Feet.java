
public class Feet {
	public int convertfeet(int var1) {
		int x=5;
		System.out.println("Centimetres into feet" + x );
		return x;
	}

}
