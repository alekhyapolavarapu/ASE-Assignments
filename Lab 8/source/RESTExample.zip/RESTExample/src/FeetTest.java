import static org.junit.Assert.*;

import org.junit.Test;

public class FeetTest {
	Feet feet = new Feet();
      int actual = feet.convertfeet(170);
      int expected = 5;
	@Test
	public void test() {
		
		assertEquals(actual, expected);
	}

}
