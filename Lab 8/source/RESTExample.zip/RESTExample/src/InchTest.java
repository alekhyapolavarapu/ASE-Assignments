import static org.junit.Assert.*;

import org.junit.Test;

public class InchTest {
	Inch inch = new Inch();
    int actual = inch.convertinch(170);
    int expected = 64;

	@Test
	public void test() {
		assertEquals(actual, expected);
	}
	}


